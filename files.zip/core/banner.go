package core

const (
	Name    = "shhgit"
	Version = "0.4"
	Author  = "Paul Price (@darkp0rt) - www.darkport.co.uk"
)

const Banner = `
      _     _           _ _   
     | |   | |         (_) |  
  ___| |__ | |__   __ _ _| |_ 
 / __| '_ \| '_ \ / _` + "`" + ` | | __|
 \__ \ | | | | | | (_| | | |_ 
 |___/_| |_|_| |_|\__, |_|\__|
                   __/ |      
    v` + Version + `          |___/`
